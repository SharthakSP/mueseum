﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MuesuemForm
{
    public class Visitor
    {
        
        public int text_card_number { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string email { get; set; }
        public string occupation { get; set; }
        public string contact_number { get; set; }
        public string gender { get; set; }
        public DateTime entry_time { get; set; }
        public DateTime exit_time { get; set; }
    }
}

