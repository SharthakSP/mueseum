﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MuesuemForm
{
    public partial class form_register : Form
    {
        List<Visitor> list = new List<Visitor>();
        public form_register()
        {
            InitializeComponent();
            load_from_csv();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox_gender_Enter(object sender, EventArgs e)
        {

        }

        private void rb_male_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rb_female_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button_save_Click(object sender, EventArgs e)
        {
            Visitor v = new Visitor();

            v.first_name = text_first_name.Text;
            v.last_name = text_last_name.Text;
            v.email = text_email.Text;
            v.contact_number = text_contact_number.Text;

            v.occupation = combo_box_occupation.SelectedText;
            if (rb_male.Checked)
            {
                v.gender = "Male";
            }
            else
            {
                v.gender = "Female";
            }

            v.entry_time = DateTime.Now;
           
            //to generate card_number
            Random rand = new Random();
            v.text_card_number = rand.Next(1000, 9999);

            string data = v.text_card_number + "," + v.first_name + "," + v.last_name + "," + v.email + "," + v.contact_number + "," + v.occupation + "," + v.gender + "," + v.entry_time + "," + v.exit_time + ";";
            save_to_csv(data);
            list.Add(v);
            Console.WriteLine(list[0]);
        }

        private void save_to_csv(String data)
        {
            string path = @"mueseum.csv";
            if (!File.Exists(path))
            {
                File.Create(path);
            }
            using(var write = File.AppendText(path))
            {
                write.WriteLine(data);
                //File.AppendAllText(path, data);
            }

        }

        private void load_from_csv()
        {
            List<String> list_a = new List<String>();
            string path = @"mueseum.csv";
            using (var read = new StreamReader(path))
            {
                //var lines = read.ReadLine().Split(';');

                String lines;
                    while((lines = read.ReadLine())!= null)
                {
                        var split_lines = lines.Split(';');
                        list_a.Add(split_lines[0]);
                        //Console.WriteLine(list_a);          
                    //Console.WriteLine(split_lines[0]);
                }
                //Console.WriteLine(list_a[0]);
                   // read.Close();    
            }
        }

    }
}
